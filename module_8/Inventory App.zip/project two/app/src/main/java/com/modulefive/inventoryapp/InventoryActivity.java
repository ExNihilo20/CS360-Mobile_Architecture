package com.modulefive.inventoryapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    // for logging purposes
    private static final String TAG = "InventoryActivity";

    private static final int SMS_PERMISSION_REQUEST_CODE = 1; // Request code for SMS permission
    private static final int LOW_INVENTORY_THRESHOLD = 5; // Define the low inventory threshold
    private RecyclerView inventoryRecyclerView;
    private InventoryAdapter adapter;
    private List<InventoryItem> inventoryItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        inventoryRecyclerView = findViewById(R.id.inventoryRecyclerView);
        FloatingActionButton addItemButton = findViewById(R.id.addItemButton);
        Button backButton = findViewById(R.id.backButton);

        inventoryItems = new ArrayList<>();
        // Sample data
        inventoryItems.add(new InventoryItem("Item 1", 10));
        inventoryItems.add(new InventoryItem("Item 2", 5));
        inventoryItems.add(new InventoryItem("Item 3", 20));

        adapter = new InventoryAdapter(inventoryItems);
        inventoryRecyclerView.setAdapter(adapter);
        inventoryRecyclerView.setLayoutManager(new GridLayoutManager(this, 2)); // 2 columns

        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddItemDialog();
            }
        });

        // Set up back button click listener
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryActivity.this, DashboardActivity.class);
                startActivity(intent);
            }
        });

        checkSmsPermission();
    }

    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item");

        // Set up the input fields
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_item, null);
        final EditText itemNameInput = dialogView.findViewById(R.id.itemNameInput);
        final EditText itemQuantityInput = dialogView.findViewById(R.id.itemQuantityInput);

        builder.setView(dialogView);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String itemName = itemNameInput.getText().toString();
                int itemQuantity = Integer.parseInt(itemQuantityInput.getText().toString());

                // Add the new item to the list and notify the adapter
                inventoryItems.add(new InventoryItem(itemName, itemQuantity));
                adapter.notifyDataSetChanged();

                // Check for low inventory and send notification if necessary
                checkAndSendLowInventoryNotification(itemName, itemQuantity);
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    private void checkAndSendLowInventoryNotification(String itemName, int quantity) {
        if (quantity < LOW_INVENTORY_THRESHOLD) {
            SmsNotificationUtil.sendLowInventoryNotification(this, itemName, quantity);
        }
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SmsNotificationUtil.SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                // Optionally, you can resend the notification here if it was triggered before
            } else {
                Toast.makeText(this, "SMS permission denied. Notifications will not be sent.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

        private List<InventoryItem> items;

        InventoryAdapter(List<InventoryItem> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // Inflate the item layout
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            InventoryItem item = items.get(position);
            holder.itemName.setText(item.getName());
            holder.itemQuantity.setText(String.valueOf(item.getQuantity()));

            // Set up the delete button click listener
            holder.deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Get the current adapter position
                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION) { // Check if position is valid
                        // Remove the item from the list
                        items.remove(adapterPosition);
                        // Notify the adapter about the removed item
                        notifyItemRemoved(adapterPosition);
                        notifyItemRangeChanged(adapterPosition, items.size());
                        Toast.makeText(v.getContext(), "Deleted " + item.getName(), Toast.LENGTH_SHORT).show();
                    }
                }
            });

            // Set up the update button click listener
            holder.updateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showUpdateQuantityDialog(item); // Show dialog to update quantity for this item
                }
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView itemName;
            TextView itemQuantity;
            Button deleteButton;
            Button updateButton; // Add update button

            ViewHolder(View itemView) {
                super(itemView);
                itemName = itemView.findViewById(R.id.itemName);
                itemQuantity = itemView.findViewById(R.id.itemQuantity);
                deleteButton = itemView.findViewById(R.id.deleteButton);
                updateButton = itemView.findViewById(R.id.updateButton); // Initialize update button
            }
        }
    }

    private void showUpdateQuantityDialog(final InventoryItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Quantity for " + item.getName());

        final EditText quantityInput = new EditText(this);
        quantityInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        quantityInput.setHint("Enter new quantity");
        quantityInput.setText(String.valueOf(item.getQuantity()));

        builder.setView(quantityInput);

        builder.setPositiveButton("Update", null); // Set to null here

        final AlertDialog dialog = builder.create();
        dialog.show();

        // Set the click listener after showing the dialog
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = quantityInput.getText().toString();
                if (input.isEmpty()) {
                    Toast.makeText(InventoryActivity.this, "Quantity cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int newQuantity = Integer.parseInt(input);
                    if (newQuantity < 0) {
                        Toast.makeText(InventoryActivity.this, "Quantity cannot be negative", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Log.d(TAG, "Updating quantity for " + item.getName() + " to " + newQuantity);
                    item.setQuantity(newQuantity);
                    adapter.notifyDataSetChanged();

                    // Check for low inventory and send notification if necessary
                    checkAndSendLowInventoryNotification(item.getName(), newQuantity);

                    Toast.makeText(InventoryActivity.this, "Quantity updated successfully", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                } catch (NumberFormatException e) {
                    Toast.makeText(InventoryActivity.this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Log.e(TAG, "Error updating quantity", e);
                    Toast.makeText(InventoryActivity.this, "An error occurred while updating quantity", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // This class represents an inventory item
    private static class InventoryItem {
        private String name;
        private int quantity;

        InventoryItem(String name, int quantity) {
            this.name = name;
            this.quantity = quantity;
        }

        String getName() {
            return name;
        }

        int getQuantity() {
            return quantity;
        }

        void setQuantity(int quantity) {
            this.quantity = quantity;
        }
    }
}